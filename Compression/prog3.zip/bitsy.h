unsigned short read_byte();
unsigned short read_bit();
void write_byte(unsigned char byt);
void write_bit(unsigned char bit);
void flush_write_buffer();
struct Byte;
