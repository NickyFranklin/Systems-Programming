#define OPEN_CALL       1
#define CLOSE_CALL      2
#define READ_CALL       3
#define WRITE_CALL      4
#define LSEEK_CALL      5
#define CHECKSUM_CALL   6
